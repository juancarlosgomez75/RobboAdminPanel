@extends('paneltemplate')
@section('title','Creación de manager')

</style>
@section("contenido")
@livewire("estudios.manager-create",["IdEstudio"=>$IdEstudio])

@endsection
