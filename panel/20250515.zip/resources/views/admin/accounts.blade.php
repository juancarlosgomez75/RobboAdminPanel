@extends('paneltemplate')
@section('title','Administración de cuentas')

@section("contenido")
@livewire("admin.accounts")

@endsection
