
<ui-menu-checkbox-group <?php echo e($attributes); ?> data-flux-menu-checkbox-group>
    <?php echo e($slot); ?>

</ui-menu-checkbox-group>
<?php /**PATH C:\xampp\htdocs\RobboAdminPanel\panel\vendor\livewire\flux\stubs\resources\views\flux\menu\checkbox\group.blade.php ENDPATH**/ ?>