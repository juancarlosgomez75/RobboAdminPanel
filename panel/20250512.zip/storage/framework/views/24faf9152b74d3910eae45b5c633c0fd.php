<?php $__env->startComponent('mail::message'); ?>
# ¡Bienvenido a nuestra aplicación!

Gracias por registrarte. Nos alegra que formes parte de nuestra comunidad.

<?php $__env->startComponent('mail::button', ['url' => "1"]); ?>
    Ir al sitio
<?php echo $__env->renderComponent(); ?>

Este es un correo electrónico de prueba, diseñado con una plantilla personalizada.

¡Gracias por ser parte de nuestra comunidad!<br>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\RobboAdminPanel\panel\resources\views/viewcorreo.blade.php ENDPATH**/ ?>