<?php

namespace App\Livewire\Modelos;

use Livewire\Component;

class Listado extends Component
{
    public function render()
    {
        return view('livewire.modelos.listado');
    }
}
