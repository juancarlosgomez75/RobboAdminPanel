<?php $__env->startSection('title','Home'); ?>

<?php $__env->startSection("contenido"); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('paneltemplate', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /opt/lampp/htdocs/RobboAdminPanel/panel/resources/views/admin/index.blade.php ENDPATH**/ ?>