<?php $__env->startSection('title','Visualización de estudio'); ?>

</style>
<?php $__env->startSection("contenido"); ?>
<?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split("estudios.viewedit",["Informacion"=>$Information,"Managers"=>$Managers,"Maquinas"=>$Machines,"Ciudades"=>$Ciudades]);

$__html = app('livewire')->mount($__name, $__params, 'lw-944557425-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('paneltemplate', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /opt/lampp/htdocs/RobboAdminPanel/panel/resources/views/estudios/viewedit.blade.php ENDPATH**/ ?>