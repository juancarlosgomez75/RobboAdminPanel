@extends('paneltemplate')
@section('title','Crear movimiento')
@section("contenido")

@livewire("inventario.movement",compact("inventory"))

@endsection
