@extends('paneltemplate')
@section('title','Crear pedido')
@section("contenido")

@livewire("inventario.request")

@endsection
