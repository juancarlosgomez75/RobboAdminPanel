@extends('paneltemplate')
@section('title','Crear orden')
@section("contenido")

@livewire("inventario.order")

@endsection
