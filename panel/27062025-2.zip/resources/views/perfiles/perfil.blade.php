@extends('paneltemplate')
@section('title','Mi perfil')

@section("contenido")
@livewire("perfiles.perfil")

@endsection
