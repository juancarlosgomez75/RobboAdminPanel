@extends('paneltemplate')
@section('title','Creación de modelo')

@section("contenido")
@livewire("modelos.create",compact("idestudio"))

@endsection
