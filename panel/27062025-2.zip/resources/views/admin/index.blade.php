@extends('paneltemplate')
@section('title','Home')

@section("contenido")

@endsection
