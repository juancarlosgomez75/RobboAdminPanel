
<legend <?php echo e($attributes->class('text-base font-medium text-zinc-800 dark:text-white')); ?> data-flux-legend>
    <?php echo e($slot); ?>

</legend>
<?php /**PATH C:\xampp\htdocs\RobboAdminPanel\panel\vendor\livewire\flux\stubs\resources\views\flux\legend.blade.php ENDPATH**/ ?>