
<ui-close data-flux-modal-close>
    <?php echo e($slot); ?>

</ui-close>
<?php /**PATH C:\xampp\htdocs\RobboAdminPanel\panel\vendor\livewire\flux\stubs\resources\views\flux\modal\close.blade.php ENDPATH**/ ?>